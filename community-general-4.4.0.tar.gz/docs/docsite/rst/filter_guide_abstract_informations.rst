Abstract transformations
------------------------

.. toctree::
   :maxdepth: 1

   filter_guide_abstract_informations_dictionaries
   filter_guide_abstract_informations_grouping
   filter_guide_abstract_informations_merging_lists_of_dictionaries
   filter_guide_abstract_informations_counting_elements_in_sequence
